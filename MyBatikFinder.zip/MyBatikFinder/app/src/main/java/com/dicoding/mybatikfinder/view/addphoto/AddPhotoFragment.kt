package com.dicoding.mybatikfinder.view.addphoto

import androidx.fragment.app.Fragment

class AddPhotoFragment : Fragment() {

}