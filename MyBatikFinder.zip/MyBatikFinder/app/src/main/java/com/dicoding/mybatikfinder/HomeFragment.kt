package com.dicoding.mybatikfinder

import androidx.fragment.app.Fragment

class HomeFragment : Fragment() {

}
