package com.dicoding.mybatikfinder.data.api

class ApiService {
}