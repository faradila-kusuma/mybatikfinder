package com.dicoding.mybatikfinder.view.signup

import androidx.appcompat.app.AppCompatActivity

class SignupActivity : AppCompatActivity() {

}