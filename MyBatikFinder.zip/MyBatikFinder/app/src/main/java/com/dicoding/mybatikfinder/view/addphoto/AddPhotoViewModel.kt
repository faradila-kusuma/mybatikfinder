package com.dicoding.mybatikfinder.view.addphoto

import androidx.lifecycle.ViewModel
import com.dicoding.mybatikfinder.data.pref.UserRepository

class AddPhotoViewModel (private  val userRepository: UserRepository): ViewModel(){

}